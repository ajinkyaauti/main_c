# Development Environment Setup Guide

## Prerequisites

### 1. Compiler Installation

**Windows:**
```powershell
# Install Visual Studio 2022 Community (recommended)
# Download from: https://visualstudio.microsoft.com/

# Or install MinGW-w64 with MSYS2
winget install MSYS2.MSYS2
# Then in MSYS2 terminal:
pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-gdb
```

**Ensure C++17/20 support:**
- GCC 9+ or Clang 10+ or MSVC 2019+

### 2. CMake Installation

```powershell
# Windows
winget install Kitware.CMake

# Verify installation
cmake --version  # Should be 3.16+
```

### 3. Version Control

```powershell
# Install Git
winget install Git.Git

# Configure
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### 4. Package Manager (vcpkg)

```powershell
# Clone vcpkg
cd C:\dev
git clone https://github.com/Microsoft/vcpkg.git
cd vcpkg
.\bootstrap-vcpkg.bat

# Add to PATH or integrate with Visual Studio
.\vcpkg integrate install

# Set environment variable
[System.Environment]::SetEnvironmentVariable('VCPKG_ROOT', 'C:\dev\vcpkg', 'User')
```

---

## Essential Libraries Installation

### Core Dependencies

```powershell
# Navigate to your vcpkg directory
cd $env:VCPKG_ROOT

# Install essential libraries
.\vcpkg install boost-asio:x64-windows
.\vcpkg install nlohmann-json:x64-windows
.\vcpkg install spdlog:x64-windows
.\vcpkg install gtest:x64-windows
.\vcpkg install fmt:x64-windows
.\vcpkg install openssl:x64-windows

# Optional but recommended
.\vcpkg install protobuf:x64-windows
.\vcpkg install sqlite3:x64-windows
.\vcpkg install catch2:x64-windows
```

---

## IDE Setup

### Option 1: Visual Studio Code (Recommended)

```powershell
# Install VS Code
winget install Microsoft.VisualStudioCode
```

**Essential Extensions:**
- C/C++ (Microsoft)
- CMake Tools (Microsoft)
- CMake (twxs)
- C++ TestMate
- GitLens
- Better C++ Syntax

**VS Code Settings (`.vscode/settings.json`):**
```json
{
  "C_Cpp.default.configurationProvider": "ms-vscode.cmake-tools",
  "cmake.configureOnOpen": true,
  "C_Cpp.default.cppStandard": "c++20",
  "C_Cpp.default.compilerPath": "C:/msys64/mingw64/bin/g++.exe",
  "editor.formatOnSave": true,
  "C_Cpp.clang_format_fallbackStyle": "Google"
}
```

### Option 2: Visual Studio 2022 (Alternative)

- Full IDE with excellent debugging
- CMake support built-in
- Best for Windows development

### Option 3: CLion (Paid, but excellent)

- Best CMake integration
- Powerful refactoring tools
- Built-in profiler

---

## Project Template Structure

Create this structure for each project:

```
project-name/
├── CMakeLists.txt
├── README.md
├── .gitignore
├── include/
│   └── project-name/
│       └── *.h
├── src/
│   └── *.cpp
├── tests/
│   ├── CMakeLists.txt
│   └── *_test.cpp
├── examples/
│   └── example_usage.cpp
├── docs/
│   └── DESIGN.md
└── build/  (gitignored)
```

---

## CMake Template

**Root `CMakeLists.txt`:**

```cmake
cmake_minimum_required(VERSION 3.16)
project(ProjectName VERSION 1.0.0 LANGUAGES CXX)

# C++ Standard
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Compiler warnings
if(MSVC)
    add_compile_options(/W4 /WX)
else()
    add_compile_options(-Wall -Wextra -Wpedantic -Werror)
endif()

# Find vcpkg packages
find_package(Boost REQUIRED COMPONENTS system)
find_package(nlohmann_json CONFIG REQUIRED)
find_package(spdlog CONFIG REQUIRED)

# Include directories
include_directories(include)

# Source files
file(GLOB_RECURSE SOURCES "src/*.cpp")

# Main library
add_library(${PROJECT_NAME} ${SOURCES})
target_link_libraries(${PROJECT_NAME} 
    PRIVATE 
    Boost::system
    nlohmann_json::nlohmann_json
    spdlog::spdlog
)

# Main executable
add_executable(${PROJECT_NAME}_main src/main.cpp)
target_link_libraries(${PROJECT_NAME}_main PRIVATE ${PROJECT_NAME})

# Enable testing
enable_testing()
add_subdirectory(tests)

# Installation
install(TARGETS ${PROJECT_NAME} ${PROJECT_NAME}_main
    LIBRARY DESTINATION lib
    RUNTIME DESTINATION bin
)
```

**`tests/CMakeLists.txt`:**

```cmake
find_package(GTest CONFIG REQUIRED)

file(GLOB_RECURSE TEST_SOURCES "*_test.cpp")

foreach(test_file ${TEST_SOURCES})
    get_filename_component(test_name ${test_file} NAME_WE)
    add_executable(${test_name} ${test_file})
    target_link_libraries(${test_name} 
        PRIVATE 
        ${PROJECT_NAME}
        GTest::gtest 
        GTest::gtest_main
    )
    add_test(NAME ${test_name} COMMAND ${test_name})
endforeach()
```

---

## `.gitignore` Template

```gitignore
# Build directories
build/
cmake-build-*/
out/

# IDE files
.vscode/
.vs/
.idea/
*.suo
*.user
*.sln.docstates

# Compiled files
*.exe
*.dll
*.so
*.dylib
*.a
*.lib
*.o
*.obj

# CMake
CMakeCache.txt
CMakeFiles/
cmake_install.cmake
Makefile

# Testing
Testing/
*.test

# Logs
*.log

# OS files
.DS_Store
Thumbs.db
```

---

## Building Your First Project

### 1. Create Project Structure

```powershell
# Navigate to your workspace
cd C:\Users\ajauti\Desktop\Learn\backend_cpp

# Create a sample project
mkdir hello-server
cd hello-server

# Create directories
mkdir include, src, tests
mkdir include/hello-server
```

### 2. Create a Simple Hello Server

**`include/hello-server/server.h`:**
```cpp
#pragma once
#include <string>

namespace hello {
    class Server {
    public:
        explicit Server(int port);
        void start();
        void stop();
    private:
        int port_;
        bool running_{false};
    };
}
```

**`src/server.cpp`:**
```cpp
#include "hello-server/server.h"
#include <spdlog/spdlog.h>
#include <iostream>

namespace hello {
    Server::Server(int port) : port_(port) {
        spdlog::info("Server initialized on port {}", port_);
    }

    void Server::start() {
        running_ = true;
        spdlog::info("Server starting...");
        // TODO: Implement socket logic
    }

    void Server::stop() {
        running_ = false;
        spdlog::info("Server stopped");
    }
}
```

**`src/main.cpp`:**
```cpp
#include "hello-server/server.h"
#include <spdlog/spdlog.h>

int main() {
    spdlog::set_level(spdlog::level::info);
    
    hello::Server server(8080);
    server.start();
    
    return 0;
}
```

### 3. Add CMakeLists.txt (use template above)

### 4. Build

```powershell
# Configure
cmake -B build -S . -DCMAKE_TOOLCHAIN_FILE=$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake

# Build
cmake --build build --config Release

# Run
.\build\Release\hello-server_main.exe
```

---

## Debugging Tools

### 1. AddressSanitizer (Memory Errors)

```powershell
# Add to CMakeLists.txt for Debug builds
set(CMAKE_CXX_FLAGS_DEBUG "${CMAKE_CXX_FLAGS_DEBUG} -fsanitize=address")
```

### 2. ThreadSanitizer (Race Conditions)

```cmake
set(CMAKE_CXX_FLAGS_DEBUG "${CMAKE_CXX_FLAGS_DEBUG} -fsanitize=thread")
```

### 3. Debugging in VS Code

**`.vscode/launch.json`:**
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Debug",
      "type": "cppdbg",
      "request": "launch",
      "program": "${workspaceFolder}/build/Debug/${workspaceFolderBasename}_main.exe",
      "args": [],
      "stopAtEntry": false,
      "cwd": "${workspaceFolder}",
      "environment": [],
      "externalConsole": false,
      "MIMode": "gdb",
      "miDebuggerPath": "C:/msys64/mingw64/bin/gdb.exe",
      "setupCommands": [
        {
          "description": "Enable pretty-printing",
          "text": "-enable-pretty-printing",
          "ignoreFailures": true
        }
      ]
    }
  ]
}
```

---

## Performance Profiling (Windows)

### Using Windows Performance Analyzer

```powershell
# Windows Performance Recorder (built-in)
# Or use Very Sleepy (free profiler)
choco install very-sleepy
```

### Using perf (WSL2 alternative)

If you use WSL2 for development:
```bash
sudo apt install linux-tools-generic
perf record -g ./your_program
perf report
```

---

## Testing Setup

### Running Tests

```powershell
# Build tests
cmake --build build --target all

# Run all tests
ctest --test-dir build --output-on-failure

# Run specific test
.\build\tests\server_test.exe
```

### Coverage (requires GCC/Clang)

```cmake
# Add to CMakeLists.txt
option(ENABLE_COVERAGE "Enable coverage reporting" OFF)
if(ENABLE_COVERAGE)
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} --coverage")
endif()
```

```powershell
# Generate coverage
cmake -B build -DENABLE_COVERAGE=ON
cmake --build build
ctest --test-dir build
gcovr -r . --html --html-details -o coverage.html
```

---

## Load Testing Tools

```powershell
# Install wrk (if using WSL2)
# Or use Apache Bench
choco install apache-httpd

# Test your server
ab -n 10000 -c 100 http://localhost:8080/
```

---

## Quick Reference Commands

```powershell
# Build commands
cmake -B build -S .                    # Configure
cmake --build build                    # Build
cmake --build build --target clean     # Clean

# Testing
ctest --test-dir build --verbose       # Run tests with output

# Installation
cmake --install build --prefix /usr/local

# Format code (requires clang-format)
clang-format -i src/*.cpp include/**/*.h
```

---

## Troubleshooting

### vcpkg packages not found
```powershell
# Ensure VCPKG_ROOT is set
echo $env:VCPKG_ROOT

# Re-integrate
cd $env:VCPKG_ROOT
.\vcpkg integrate install
```

### Compiler errors about C++20
```cmake
# Explicitly set in CMakeLists.txt
set(CMAKE_CXX_STANDARD 20)
target_compile_features(your_target PUBLIC cxx_std_20)
```

### Linking errors
```cmake
# Add verbose output
set(CMAKE_VERBOSE_MAKEFILE ON)
```

---

## Ready to Start?

1. ✅ Verify all tools are installed: `cmake --version`, `git --version`, `g++ --version`
2. ✅ Create your first project from the template
3. ✅ Build and run the hello-server example
4. ✅ Start Week 1 of the curriculum!

---

**Next:** Review [CURRICULUM.md](CURRICULUM.md) and begin Week 1 exercises.
