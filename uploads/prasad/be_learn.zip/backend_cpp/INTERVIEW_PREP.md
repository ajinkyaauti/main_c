# C++ Backend Interview Cheat Sheet

> Quick reference for common patterns, best practices, and interview topics

---

## 🎯 System Design Template

### Step 1: Requirements Clarification (5 min)

**Functional Requirements:**
- What operations? (CRUD, search, etc.)
- What scale? (users, requests/sec, data size)
- What features are must-have vs nice-to-have?

**Non-Functional Requirements:**
- **Latency:** Response time expectations?
- **Throughput:** Requests/sec?
- **Availability:** 99.9%? 99.99%?
- **Consistency:** Strong vs eventual?
- **Durability:** Data loss tolerance?

### Step 2: Capacity Estimation (5 min)

```
Example: URL Shortener

Traffic:
- 500M URL shortens/month
- 5:1 read-write ratio
- 2500M reads/month

QPS:
- Writes: 500M / (30 * 24 * 3600) ≈ 200 writes/sec
- Reads: 200 * 5 = 1000 reads/sec

Storage:
- 500 bytes/URL × 500M = 250 GB/month
- 5 years = 15 TB

Bandwidth:
- Ingress: 200 * 500 bytes = 100 KB/sec
- Egress: 1000 * 500 bytes = 500 KB/sec
```

### Step 3: High-Level Design (10 min)

Draw boxes:
- **Client** → **Load Balancer** → **API Servers**
- **Cache** (Redis)
- **Database** (Master-Slave)
- **Queue** (for async tasks)

### Step 4: Detailed Design (15 min)

**API Design:**
```cpp
// URL Shortener
POST   /api/v1/shorten     { "url": "..." } → { "short_url": "..." }
GET    /api/v1/{short_id}  → Redirect to original URL
DELETE /api/v1/{short_id}  → 204 No Content
```

**Data Model:**
```sql
CREATE TABLE urls (
    short_id VARCHAR(10) PRIMARY KEY,
    original_url TEXT NOT NULL,
    user_id BIGINT,
    created_at TIMESTAMP,
    expires_at TIMESTAMP,
    clicks BIGINT DEFAULT 0
);
CREATE INDEX idx_user_id ON urls(user_id);
CREATE INDEX idx_created_at ON urls(created_at);
```

**Algorithm (Base62 encoding):**
```cpp
std::string encode(uint64_t id) {
    const char* base62 = 
        "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    std::string result;
    while (id > 0) {
        result = base62[id % 62] + result;
        id /= 62;
    }
    return result;
}
```

### Step 5: Scaling & Reliability (10 min)

**Bottlenecks:**
- Database writes? → Sharding
- Read-heavy? → Caching + Read replicas
- Single point of failure? → Replication

**Trade-offs:**
- Strong consistency → Higher latency, lower availability
- Eventual consistency → Lower latency, higher availability
- Normalization → Easier updates, slower reads
- Denormalization → Faster reads, harder updates

---

## 🧵 Concurrency Patterns

### 1. Producer-Consumer

```cpp
#include <queue>
#include <mutex>
#include <condition_variable>

template<typename T>
class ThreadSafeQueue {
public:
    void push(T value) {
        std::unique_lock<std::mutex> lock(mutex_);
        queue_.push(std::move(value));
        cv_.notify_one();
    }
    
    T pop() {
        std::unique_lock<std::mutex> lock(mutex_);
        cv_.wait(lock, [this] { return !queue_.empty(); });
        T value = std::move(queue_.front());
        queue_.pop();
        return value;
    }
    
    bool try_pop(T& value, std::chrono::milliseconds timeout) {
        std::unique_lock<std::mutex> lock(mutex_);
        if (!cv_.wait_for(lock, timeout, [this] { return !queue_.empty(); })) {
            return false;
        }
        value = std::move(queue_.front());
        queue_.pop();
        return true;
    }
    
private:
    std::queue<T> queue_;
    std::mutex mutex_;
    std::condition_variable cv_;
};
```

### 2. Reader-Writer Lock

```cpp
#include <shared_mutex>

class Data {
public:
    int read() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return value_;
    }
    
    void write(int value) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        value_ = value;
    }
    
private:
    mutable std::shared_mutex mutex_;
    int value_{0};
};
```

### 3. Thread Pool

```cpp
class ThreadPool {
public:
    explicit ThreadPool(size_t num_threads) {
        for (size_t i = 0; i < num_threads; ++i) {
            workers_.emplace_back([this] {
                while (true) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lock(mutex_);
                        cv_.wait(lock, [this] { 
                            return stop_ || !tasks_.empty(); 
                        });
                        if (stop_ && tasks_.empty()) return;
                        task = std::move(tasks_.front());
                        tasks_.pop();
                    }
                    task();
                }
            });
        }
    }
    
    ~ThreadPool() {
        {
            std::unique_lock<std::mutex> lock(mutex_);
            stop_ = true;
        }
        cv_.notify_all();
        for (auto& worker : workers_) {
            worker.join();
        }
    }
    
    template<typename F>
    void enqueue(F&& task) {
        {
            std::unique_lock<std::mutex> lock(mutex_);
            tasks_.emplace(std::forward<F>(task));
        }
        cv_.notify_one();
    }
    
private:
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex mutex_;
    std::condition_variable cv_;
    bool stop_{false};
};
```

### 4. Double-Checked Locking (Singleton)

```cpp
class Singleton {
public:
    static Singleton& instance() {
        // C++11 guarantees thread-safe initialization
        static Singleton instance;
        return instance;
    }
    
private:
    Singleton() = default;
    Singleton(const Singleton&) = delete;
    Singleton& operator=(const Singleton&) = delete;
};

// Or with explicit synchronization:
class Singleton2 {
public:
    static Singleton2* instance() {
        Singleton2* tmp = instance_.load(std::memory_order_acquire);
        if (tmp == nullptr) {
            std::lock_guard<std::mutex> lock(mutex_);
            tmp = instance_.load(std::memory_order_relaxed);
            if (tmp == nullptr) {
                tmp = new Singleton2();
                instance_.store(tmp, std::memory_order_release);
            }
        }
        return tmp;
    }
    
private:
    static std::atomic<Singleton2*> instance_;
    static std::mutex mutex_;
};
```

---

## 📊 Data Structures Deep Dive

### STL Container Selection

| Use Case | Container | Time Complexity | When to Use |
|----------|-----------|----------------|-------------|
| Fast lookup by key | `unordered_map` | O(1) avg | Hash-based, no ordering needed |
| Ordered traversal | `map` | O(log n) | Need sorted keys |
| Fast random access | `vector` | O(1) | Dynamic array |
| Fast insert/delete | `list` | O(1) | At known position |
| Priority queue | `priority_queue` | O(log n) | Max/min heap |
| Unique, sorted | `set` | O(log n) | BST, no duplicates |
| FIFO queue | `queue` | O(1) | BFS, producer-consumer |
| LIFO stack | `stack` | O(1) | DFS, undo/redo |

### Custom Hash Function

```cpp
struct Pair {
    int x, y;
    
    bool operator==(const Pair& other) const {
        return x == other.x && y == other.y;
    }
};

namespace std {
    template<>
    struct hash<Pair> {
        size_t operator()(const Pair& p) const {
            return hash<int>()(p.x) ^ (hash<int>()(p.y) << 1);
        }
    };
}

// Usage:
std::unordered_map<Pair, std::string> map;
```

### LRU Cache Implementation

```cpp
class LRUCache {
public:
    explicit LRUCache(size_t capacity) : capacity_(capacity) {}
    
    int get(int key) {
        auto it = cache_.find(key);
        if (it == cache_.end()) return -1;
        
        // Move to front
        lru_list_.splice(lru_list_.begin(), lru_list_, it->second);
        return it->second->second;
    }
    
    void put(int key, int value) {
        auto it = cache_.find(key);
        if (it != cache_.end()) {
            // Update existing
            it->second->second = value;
            lru_list_.splice(lru_list_.begin(), lru_list_, it->second);
            return;
        }
        
        if (cache_.size() >= capacity_) {
            // Evict LRU
            int old_key = lru_list_.back().first;
            lru_list_.pop_back();
            cache_.erase(old_key);
        }
        
        // Insert new
        lru_list_.emplace_front(key, value);
        cache_[key] = lru_list_.begin();
    }
    
private:
    size_t capacity_;
    std::list<std::pair<int, int>> lru_list_;  // {key, value}
    std::unordered_map<int, std::list<std::pair<int, int>>::iterator> cache_;
};
```

---

## ⚡ Performance Optimization Checklist

### Memory Optimization

```cpp
// ❌ Bad: Unnecessary copies
std::vector<std::string> filter(const std::vector<std::string>& items) {
    std::vector<std::string> result;
    for (auto item : items) {  // Copy!
        if (is_valid(item)) {
            result.push_back(item);  // Another copy!
        }
    }
    return result;
}

// ✅ Good: Move semantics
std::vector<std::string> filter(const std::vector<std::string>& items) {
    std::vector<std::string> result;
    result.reserve(items.size());  // Pre-allocate
    for (const auto& item : items) {  // Reference
        if (is_valid(item)) {
            result.push_back(item);  // Copy is necessary
        }
    }
    return result;  // RVO (Return Value Optimization)
}

// ✅ Better: In-place modification
void filter_inplace(std::vector<std::string>& items) {
    auto it = std::remove_if(items.begin(), items.end(), 
        [](const auto& item) { return !is_valid(item); });
    items.erase(it, items.end());
}
```

### Cache Optimization

```cpp
// ❌ Bad: Poor cache locality
struct Data {
    int id;
    char padding1[60];
    int value;
    char padding2[60];
};
std::vector<Data> data;

// ✅ Good: Structure of Arrays (SoA)
struct DataSoA {
    std::vector<int> ids;
    std::vector<int> values;
};

// Sequential access pattern
for (size_t i = 0; i < data.ids.size(); ++i) {
    process(data.ids[i], data.values[i]);
}
```

### Avoid Allocations in Hot Path

```cpp
// ❌ Bad: Allocates every call
std::string format_message(int id, const std::string& name) {
    return "User " + std::to_string(id) + ": " + name;  // 3 allocations!
}

// ✅ Good: Pre-allocated buffer
class MessageFormatter {
public:
    std::string_view format(int id, const std::string& name) {
        buffer_.clear();
        buffer_ = "User ";
        buffer_ += std::to_string(id);
        buffer_ += ": ";
        buffer_ += name;
        return buffer_;
    }
    
private:
    std::string buffer_;
};
```

---

## 🔒 Common Pitfalls & Solutions

### 1. Deadlock Prevention

```cpp
// ❌ Bad: Different lock order → deadlock
void transfer(Account& from, Account& to, int amount) {
    std::lock_guard<std::mutex> lock1(from.mutex);
    std::lock_guard<std::mutex> lock2(to.mutex);  // Deadlock if reverse order elsewhere!
    from.balance -= amount;
    to.balance += amount;
}

// ✅ Good: Consistent lock order or std::lock
void transfer(Account& from, Account& to, int amount) {
    std::lock(from.mutex, to.mutex);  // Locks both atomically
    std::lock_guard<std::mutex> lock1(from.mutex, std::adopt_lock);
    std::lock_guard<std::mutex> lock2(to.mutex, std::adopt_lock);
    from.balance -= amount;
    to.balance += amount;
}
```

### 2. False Sharing

```cpp
// ❌ Bad: False sharing (both on same cache line)
struct Counter {
    std::atomic<int> count1;
    std::atomic<int> count2;  // Likely on same cache line as count1
};

// ✅ Good: Cache line padding
struct Counter {
    alignas(64) std::atomic<int> count1;  // 64 = typical cache line size
    alignas(64) std::atomic<int> count2;
};
```

### 3. Exception Safety

```cpp
// ❌ Bad: Not exception-safe
void process(Data* data) {
    Resource* res = new Resource();
    data->use(res);  // May throw!
    delete res;  // Leaked if exception thrown
}

// ✅ Good: RAII
void process(Data* data) {
    auto res = std::make_unique<Resource>();
    data->use(res.get());
    // Automatic cleanup, exception-safe
}
```

---

## 🎤 Behavioral Interview STAR Examples

### Example 1: Technical Challenge

**Situation:** Building HTTP server for 10K+ concurrent connections  
**Task:** Needed to reduce CPU usage from 80% to <30%  
**Action:**
- Profiled with `perf` and found `recv()` calls were blocking
- Switched from thread-per-connection to epoll-based async I/O
- Implemented connection pooling with keep-alive

**Result:**
- CPU usage dropped to 15%
- Throughput increased from 20K to 55K req/sec
- Latency p99 improved from 50ms to 8ms

### Example 2: Debugging Race Condition

**Situation:** KV store occasionally returned stale data  
**Task:** Find and fix the race condition  
**Action:**
- Reproduced under ThreadSanitizer
- Identified read-after-write race in cache update
- Changed from mutex to shared_mutex (reader-writer lock)
- Added happens-before relationship with memory barriers

**Result:**
- Eliminated all race conditions (clean ThreadSanitizer runs)
- Read throughput increased 3x (multiple readers allowed)
- No correctness issues in 72hr stress test

---

## 📝 Quick Code Review Checklist

### Before Submitting PR

- [ ] **Compiles cleanly** (no warnings with `-Wall -Wextra`)
- [ ] **All tests pass** (unit + integration)
- [ ] **No memory leaks** (Valgrind clean)
- [ ] **No data races** (ThreadSanitizer clean)
- [ ] **Code formatted** (clang-format)
- [ ] **Comments explain "why"**, not "what"
- [ ] **Error handling** comprehensive
- [ ] **Documentation updated** (README, API docs)
- [ ] **Performance acceptable** (benchmarked if hot path)

---

## 🚀 Day-Before-Interview Checklist

- [ ] Review all project READMEs
- [ ] Can explain every design decision
- [ ] Practiced 3+ system design problems
- [ ] Reviewed concurrency patterns
- [ ] Fresh on STL complexity
- [ ] Prepared questions to ask interviewer
- [ ] Good sleep (8 hours)
- [ ] Equipment ready (headphones, webcam, stable internet)

---

**Good luck!** 🎯
