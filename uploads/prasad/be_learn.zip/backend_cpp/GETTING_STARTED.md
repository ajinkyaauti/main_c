# Getting Started - First Steps

## 🎯 Your First 24 Hours

Welcome! Here's exactly what to do to get started with C++ backend development.

---

## Hour 1-2: Environment Setup

### Windows Setup (You're here!)

1. **Install Visual Studio 2022 Community** (Recommended)
   ```powershell
   # Using winget
   winget install Microsoft.VisualStudio.2022.Community
   ```
   During installation, select:
   - Desktop development with C++
   - CMake tools for Windows
   - C++ AddressSanitizer

   **OR** install MinGW-w64:
   ```powershell
   winget install MSYS2.MSYS2
   # Then in MSYS2 terminal:
   pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-cmake mingw-w64-x86_64-gdb
   ```

2. **Install CMake**
   ```powershell
   winget install Kitware.CMake
   ```

3. **Install Git**
   ```powershell
   winget install Git.Git
   ```

4. **Install vcpkg** (Package Manager)
   ```powershell
   cd C:\dev
   git clone https://github.com/Microsoft/vcpkg.git
   cd vcpkg
   .\bootstrap-vcpkg.bat
   .\vcpkg integrate install
   
   # Set environment variable
   [System.Environment]::SetEnvironmentVariable('VCPKG_ROOT', 'C:\dev\vcpkg', 'User')
   ```

5. **Install VS Code** (Optional but recommended)
   ```powershell
   winget install Microsoft.VisualStudioCode
   ```
   
   Install extensions:
   - C/C++ (Microsoft)
   - CMake Tools (Microsoft)
   - GitLens

---

## Hour 3: Verify Installation

```powershell
# Check versions
cmake --version      # Should be 3.16+
git --version
g++ --version        # Or check in VS Command Prompt: cl
echo $env:VCPKG_ROOT # Should show C:\dev\vcpkg
```

---

## Hour 4-5: Your First C++ Project

### Create Hello World Server

```powershell
# Create project
cd C:\Users\ajauti\Desktop\Learn\backend_cpp
mkdir hello-server
cd hello-server

# Create structure
mkdir include, src, tests
mkdir include\hello-server
```

### File 1: `CMakeLists.txt`

```cmake
cmake_minimum_required(VERSION 3.16)
project(HelloServer VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Find packages
find_package(spdlog CONFIG REQUIRED)

include_directories(include)

# Main executable
add_executable(hello_server src/main.cpp)
target_link_libraries(hello_server PRIVATE spdlog::spdlog)
```

### File 2: `src/main.cpp`

```cpp
#include <spdlog/spdlog.h>
#include <iostream>
#include <string>

int main() {
    // Configure logger
    spdlog::set_level(spdlog::level::info);
    spdlog::info("Hello Server starting...");
    
    std::string name;
    std::cout << "Enter your name: ";
    std::getline(std::cin, name);
    
    spdlog::info("Hello, {}! Welcome to C++ Backend Development!", name);
    spdlog::info("You've successfully set up your environment!");
    
    return 0;
}
```

### Build and Run

```powershell
# Install dependencies
cd $env:VCPKG_ROOT
.\vcpkg install spdlog:x64-windows

# Back to project
cd C:\Users\ajauti\Desktop\Learn\backend_cpp\hello-server

# Configure
cmake -B build -S . -DCMAKE_TOOLCHAIN_FILE=$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake

# Build
cmake --build build --config Release

# Run
.\build\Release\hello_server.exe
```

Expected output:
```
[2024-05-28 10:30:00.123] [info] Hello Server starting...
Enter your name: [Your Name]
[2024-05-28 10:30:05.456] [info] Hello, [Your Name]! Welcome to C++ Backend Development!
[2024-05-28 10:30:05.457] [info] You've successfully set up your environment!
```

✅ **If you see this, you're ready to go!**

---

## Hour 6-8: Start Week 1

Open [WEEK1_GUIDE.md](WEEK1_GUIDE.md) and begin with:

### Day 1 Exercise: Connection Pool

1. Read the smart pointers theory
2. Implement the Connection class
3. Implement the ConnectionPool class
4. Write unit tests
5. Commit to GitHub

**Time estimate:** 3-4 hours

---

## Setting Up GitHub

```powershell
# Create repo
cd C:\Users\ajauti\Desktop\Learn\backend_cpp
git init
git add .
git commit -m "Initial commit: C++ backend learning curriculum"

# Create repo on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/cpp-backend-learning.git
git branch -M main
git push -u origin main
```

### Create Good README

Your project READMEs should include:

```markdown
# Project Name

Brief description (1-2 sentences)

## Features
- Feature 1
- Feature 2

## Build Instructions
```bash
cmake -B build
cmake --build build
./build/project_name
```

## Benchmarks
- Metric 1: X ops/sec
- Metric 2: Y ms latency

## Architecture
[Diagram or description]

## Testing
```bash
ctest --test-dir build
```

Coverage: 85%

## What I Learned
- Key learning 1
- Key learning 2
```

---

## Daily Routine Suggestion

### Weekdays (2-3 hours/day)
- **Morning (1 hour):** Theory + reading
- **Evening (2 hours):** Coding exercises

### Weekends (4-6 hours/day)
- **Morning (3 hours):** Project work
- **Afternoon (2 hours):** Testing + documentation
- **Evening (1 hour):** Code review + refactor

---

## Week 1 Checklist

By the end of Week 1, you should have:

- [x] Environment set up
- [ ] Day 1-2: Smart pointers exercise completed
- [ ] Day 3-4: Move semantics exercise completed
- [ ] Day 5-6: Lambda exercise completed
- [ ] Day 7: Memory pool exercise completed
- [ ] **Week 1 Project:** Object Cache 50% done
- [ ] All code on GitHub
- [ ] Basic tests written

---

## Tracking Progress

### Update PROGRESS_TRACKER.md Daily

```markdown
## Day 1 (May 28, 2024)
**Hours:** 3
**Completed:**
- Set up environment
- Built hello world
- Started Connection Pool exercise

**Challenges:**
- vcpkg PATH issue (fixed by setting env variable)

**Tomorrow:**
- Complete Connection Pool
- Start unit tests
```

---

## Common Issues & Solutions

### Issue: vcpkg not found

**Solution:**
```powershell
# Add to PATH
$env:PATH += ";C:\dev\vcpkg"
# Or restart PowerShell after setting VCPKG_ROOT
```

### Issue: Compiler not found

**Solution:**
```powershell
# For Visual Studio, use Developer Command Prompt
# Or for MinGW:
$env:PATH += ";C:\msys64\mingw64\bin"
```

### Issue: CMake can't find packages

**Solution:**
```powershell
# Always specify toolchain file
cmake -B build -DCMAKE_TOOLCHAIN_FILE=$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake
```

### Issue: Build errors with C++20

**Solution:**
```cmake
# In CMakeLists.txt, ensure:
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
```

---

## Helpful Commands Reference

```powershell
# Build commands
cmake -B build -S .                           # Configure
cmake --build build                           # Build (Debug)
cmake --build build --config Release          # Build (Release)
cmake --build build --target clean            # Clean

# Testing
ctest --test-dir build                        # Run all tests
ctest --test-dir build --verbose              # Verbose output
ctest --test-dir build --output-on-failure    # Show failures only

# Running
.\build\Debug\project_name.exe               # Debug build
.\build\Release\project_name.exe             # Release build

# Formatting
clang-format -i src/*.cpp include/**/*.h     # Format code

# Git
git add .
git commit -m "Descriptive message"
git push
```

---

## Learning Resources for Week 1

### Videos to Watch (Total: ~3 hours)
1. **CppCon: Back to Basics - Smart Pointers** (1 hour)
2. **CppCon: Move Semantics** by Klaus Iglberger (1 hour)
3. **CppCon: Lambdas from Scratch** (45 min)

### Reading (Total: ~2 hours)
1. **Effective Modern C++:** Items 18-22 (Smart Pointers)
2. **Effective Modern C++:** Items 23-25 (Move Semantics)
3. **Effective Modern C++:** Items 31-34 (Lambdas)

### Practice (Daily)
- **LeetCode:** 1 problem/day using C++ (focus on memory management)

---

## Motivation

### Why C++ for Backend?

**Performance:**
- 10-100x faster than Python/Node.js
- Crucial for high-frequency trading, gaming servers, real-time systems

**Industry Demand:**
- Google, Facebook, Amazon use C++ for infrastructure
- All semiconductor companies (NVIDIA, Intel, AMD) rely heavily on C++
- Salaries: $120K-$200K+ for senior roles

**Career Growth:**
- Depth > Breadth: Mastering one language deeply is better
- C++ engineers are harder to find → higher demand
- Transferable skills: If you can do C++, you can do anything

---

## Week 1 Goal

**By End of Week 1, You Should Be Able To:**
- Explain smart pointers and when to use each
- Implement move constructors and assignment operators
- Write complex lambdas for STL algorithms
- Create custom memory allocators
- Build a thread-safe, production-quality cache

**This is 10% of the journey. Let's begin!** 🚀

---

## Questions?

- **Stuck?** Check [SETUP_GUIDE.md](SETUP_GUIDE.md) for detailed troubleshooting
- **Need clarity?** Re-read [CURRICULUM.md](CURRICULUM.md)
- **Want to jump ahead?** That's fine, but ensure you understand fundamentals first

---

## Ready? Start Now!

```powershell
# Open Week 1 Guide
code WEEK1_GUIDE.md

# Or just start coding!
cd C:\Users\ajauti\Desktop\Learn\backend_cpp
mkdir week1-exercises
cd week1-exercises

# Begin Exercise 1: Connection Pool
```

**Remember:** The hardest part is starting. You've already done that by reading this. Now code! 💪
