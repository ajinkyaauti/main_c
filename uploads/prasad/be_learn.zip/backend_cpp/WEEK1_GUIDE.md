# Week 1: Modern C++ Essentials

## Day 1-2: Smart Pointers & RAII

### Theory

**RAII (Resource Acquisition Is Initialization)**
- Constructor acquires resource
- Destructor releases resource
- Exception-safe by design

**Smart Pointer Types:**

```cpp
// unique_ptr - exclusive ownership
std::unique_ptr<Resource> ptr = std::make_unique<Resource>();

// shared_ptr - shared ownership (reference counted)
std::shared_ptr<Resource> ptr1 = std::make_shared<Resource>();
std::shared_ptr<Resource> ptr2 = ptr1;  // ref count = 2

// weak_ptr - non-owning reference (breaks cycles)
std::weak_ptr<Resource> weak = ptr1;
if (auto shared = weak.lock()) {
    // Use resource
}
```

### Practice Exercise 1: Custom Resource Manager

**Goal:** Build a thread-safe connection pool using smart pointers.

```cpp
// connection_pool.h
#pragma once
#include <memory>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <optional>

class Connection {
public:
    Connection(std::string host, int port);
    ~Connection();
    
    // Prevent copying
    Connection(const Connection&) = delete;
    Connection& operator=(const Connection&) = delete;
    
    // Allow moving
    Connection(Connection&&) noexcept = default;
    Connection& operator=(Connection&&) noexcept = default;
    
    void execute_query(const std::string& query);
    bool is_valid() const;
    
private:
    std::string host_;
    int port_;
    bool connected_{false};
};

class ConnectionPool {
public:
    explicit ConnectionPool(size_t pool_size, std::string host, int port);
    
    // Acquire connection with timeout
    std::unique_ptr<Connection> acquire(
        std::chrono::milliseconds timeout = std::chrono::seconds(5)
    );
    
    // Return connection to pool
    void release(std::unique_ptr<Connection> conn);
    
    size_t available() const;
    
private:
    std::queue<std::unique_ptr<Connection>> pool_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
    std::string host_;
    int port_;
};
```

**Implementation Tasks:**
1. Implement Connection class with proper RAII
2. Implement ConnectionPool with move semantics
3. Add timeout handling for acquire()
4. Write unit tests for pool exhaustion scenarios

**Test Cases:**
```cpp
// tests/connection_pool_test.cpp
#include <gtest/gtest.h>
#include "connection_pool.h"

TEST(ConnectionPoolTest, BasicAcquireRelease) {
    ConnectionPool pool(5, "localhost", 5432);
    
    auto conn = pool.acquire();
    ASSERT_NE(conn, nullptr);
    EXPECT_EQ(pool.available(), 4);
    
    pool.release(std::move(conn));
    EXPECT_EQ(pool.available(), 5);
}

TEST(ConnectionPoolTest, PoolExhaustion) {
    ConnectionPool pool(2, "localhost", 5432);
    
    auto conn1 = pool.acquire();
    auto conn2 = pool.acquire();
    
    // Third acquire should timeout
    auto conn3 = pool.acquire(std::chrono::milliseconds(100));
    EXPECT_EQ(conn3, nullptr);
}

TEST(ConnectionPoolTest, MoveSemantics) {
    ConnectionPool pool(1, "localhost", 5432);
    
    auto conn = pool.acquire();
    auto moved = std::move(conn);
    
    EXPECT_EQ(conn, nullptr);  // Original is empty
    EXPECT_NE(moved, nullptr);  // Moved-to has resource
}
```

---

## Day 3-4: Move Semantics & Perfect Forwarding

### Theory

**Lvalue vs Rvalue:**
```cpp
int x = 5;        // x is lvalue (has address)
int y = x + 1;    // x+1 is rvalue (temporary)

std::string s1 = "hello";
std::string s2 = s1;              // Copy
std::string s3 = std::move(s1);   // Move (s1 now empty)
```

**Move Constructor & Assignment:**
```cpp
class Buffer {
public:
    // Constructor
    explicit Buffer(size_t size) 
        : data_(new char[size]), size_(size) {}
    
    // Destructor
    ~Buffer() { delete[] data_; }
    
    // Copy constructor (deep copy)
    Buffer(const Buffer& other) 
        : data_(new char[other.size_]), size_(other.size_) {
        std::copy(other.data_, other.data_ + size_, data_);
    }
    
    // Move constructor (transfer ownership)
    Buffer(Buffer&& other) noexcept 
        : data_(other.data_), size_(other.size_) {
        other.data_ = nullptr;
        other.size_ = 0;
    }
    
    // Copy assignment
    Buffer& operator=(const Buffer& other) {
        if (this != &other) {
            delete[] data_;
            data_ = new char[other.size_];
            size_ = other.size_;
            std::copy(other.data_, other.data_ + size_, data_);
        }
        return *this;
    }
    
    // Move assignment
    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] data_;
            data_ = other.data_;
            size_ = other.size_;
            other.data_ = nullptr;
            other.size_ = 0;
        }
        return *this;
    }
    
private:
    char* data_;
    size_t size_;
};
```

### Practice Exercise 2: Custom Vector with Move Semantics

**Goal:** Implement a simplified std::vector with proper move semantics.

```cpp
// my_vector.h
template<typename T>
class MyVector {
public:
    MyVector() : data_(nullptr), size_(0), capacity_(0) {}
    
    explicit MyVector(size_t capacity);
    ~MyVector();
    
    // Rule of Five
    MyVector(const MyVector& other);
    MyVector(MyVector&& other) noexcept;
    MyVector& operator=(const MyVector& other);
    MyVector& operator=(MyVector&& other) noexcept;
    
    void push_back(const T& value);
    void push_back(T&& value);  // Move version
    
    template<typename... Args>
    void emplace_back(Args&&... args);  // Perfect forwarding
    
    size_t size() const { return size_; }
    size_t capacity() const { return capacity_; }
    
    T& operator[](size_t index);
    const T& operator[](size_t index) const;
    
private:
    T* data_;
    size_t size_;
    size_t capacity_;
    
    void reallocate(size_t new_capacity);
};
```

**Benchmarking Task:**
Compare performance of copy vs move:
```cpp
// Benchmark: copying 1 million strings
auto start = std::chrono::high_resolution_clock::now();

std::vector<std::string> vec_copy;
for (int i = 0; i < 1000000; ++i) {
    std::string s = "Hello World " + std::to_string(i);
    vec_copy.push_back(s);  // Copy
}

auto mid = std::chrono::high_resolution_clock::now();

std::vector<std::string> vec_move;
for (int i = 0; i < 1000000; ++i) {
    std::string s = "Hello World " + std::to_string(i);
    vec_move.push_back(std::move(s));  // Move
}

auto end = std::chrono::high_resolution_clock::now();

// Report results: move should be 2-3x faster
```

---

## Day 5-6: Lambda Expressions & Functional Programming

### Theory

**Lambda Syntax:**
```cpp
auto lambda = [capture](params) -> return_type { body };

// Examples:
auto add = [](int a, int b) { return a + b; };

int x = 10;
auto add_x = [x](int a) { return a + x; };  // Capture by value
auto add_ref = [&x](int a) { return a + x; };  // Capture by reference

// Capture all
auto capture_all_val = [=](int a) { return a + x; };
auto capture_all_ref = [&](int a) { return a + x; };

// Mutable lambda
auto counter = [count = 0]() mutable { return ++count; };
```

**STL Algorithms with Lambdas:**
```cpp
#include <algorithm>
#include <vector>

std::vector<int> nums = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

// Filter evens
auto it = std::remove_if(nums.begin(), nums.end(), 
    [](int n) { return n % 2 == 0; });
nums.erase(it, nums.end());

// Transform
std::transform(nums.begin(), nums.end(), nums.begin(),
    [](int n) { return n * n; });

// Accumulate with custom operation
int sum = std::accumulate(nums.begin(), nums.end(), 0,
    [](int acc, int n) { return acc + n; });
```

### Practice Exercise 3: Functional Query Engine

**Goal:** Build a LINQ-like query interface using lambdas.

```cpp
// query.h
template<typename T>
class Query {
public:
    explicit Query(std::vector<T> data) : data_(std::move(data)) {}
    
    // Filter
    Query where(std::function<bool(const T&)> predicate) {
        std::vector<T> filtered;
        std::copy_if(data_.begin(), data_.end(), 
                     std::back_inserter(filtered), predicate);
        return Query(std::move(filtered));
    }
    
    // Transform
    template<typename U>
    Query<U> select(std::function<U(const T&)> transform) {
        std::vector<U> transformed;
        std::transform(data_.begin(), data_.end(),
                      std::back_inserter(transformed), transform);
        return Query<U>(std::move(transformed));
    }
    
    // Aggregate
    template<typename U>
    U aggregate(U init, std::function<U(U, const T&)> operation) {
        return std::accumulate(data_.begin(), data_.end(), init, operation);
    }
    
    // Sort
    Query order_by(std::function<bool(const T&, const T&)> comparator) {
        auto sorted = data_;
        std::sort(sorted.begin(), sorted.end(), comparator);
        return Query(std::move(sorted));
    }
    
    // Take first N
    Query take(size_t n) {
        n = std::min(n, data_.size());
        return Query(std::vector<T>(data_.begin(), data_.begin() + n));
    }
    
    std::vector<T> to_vector() const { return data_; }
    
private:
    std::vector<T> data_;
};

// Usage example:
struct Person {
    std::string name;
    int age;
    double salary;
};

std::vector<Person> people = /* ... */;

auto result = Query(people)
    .where([](const Person& p) { return p.age > 25; })
    .order_by([](const Person& a, const Person& b) { 
        return a.salary > b.salary; 
    })
    .select<std::string>([](const Person& p) { return p.name; })
    .take(10)
    .to_vector();
```

---

## Day 7: Memory Pool Allocator

### Theory

**Why Custom Allocators?**
- Reduce malloc/free overhead
- Better cache locality
- Predictable performance
- Avoid fragmentation

**Simple Fixed-Size Allocator:**
```cpp
class FixedAllocator {
public:
    FixedAllocator(size_t block_size, size_t block_count);
    ~FixedAllocator();
    
    void* allocate();
    void deallocate(void* ptr);
    
private:
    struct FreeBlock {
        FreeBlock* next;
    };
    
    void* memory_;
    FreeBlock* free_list_;
    size_t block_size_;
    size_t block_count_;
};
```

### Practice Exercise 4: Object Pool

**Goal:** Implement a generic object pool with custom allocator.

```cpp
// object_pool.h
template<typename T>
class ObjectPool {
public:
    explicit ObjectPool(size_t capacity);
    ~ObjectPool();
    
    template<typename... Args>
    T* acquire(Args&&... args);
    
    void release(T* obj);
    
    size_t size() const;
    size_t available() const;
    
private:
    struct Block {
        std::aligned_storage_t<sizeof(T), alignof(T)> storage;
        bool in_use;
    };
    
    std::vector<Block> blocks_;
    std::mutex mutex_;
};
```

**Test with Benchmarks:**
```cpp
// Compare pool vs new/delete for 1M allocations
struct LargeObject {
    char data[1024];
};

// Measure pool
auto pool = ObjectPool<LargeObject>(1000);
auto start = std::chrono::high_resolution_clock::now();

for (int i = 0; i < 1000000; ++i) {
    auto obj = pool.acquire();
    // Use object
    pool.release(obj);
}

auto end = std::chrono::high_resolution_clock::now();
// Report: pool should be 5-10x faster
```

---

## Week 1 Project: Thread-Safe Object Cache

### Requirements

Build a production-ready object cache with:
1. **LRU eviction policy**
2. **Thread-safe operations**
3. **TTL (time-to-live) support**
4. **Memory limit enforcement**
5. **Hit/miss statistics**
6. **Unit tests (80%+ coverage)**

### API Design

```cpp
template<typename Key, typename Value>
class Cache {
public:
    struct Config {
        size_t max_items{1000};
        size_t max_memory_bytes{100 * 1024 * 1024};  // 100MB
        std::chrono::seconds default_ttl{300};  // 5 min
    };
    
    explicit Cache(Config config);
    
    void put(const Key& key, const Value& value, 
             std::optional<std::chrono::seconds> ttl = std::nullopt);
    
    std::optional<Value> get(const Key& key);
    
    bool contains(const Key& key) const;
    void remove(const Key& key);
    void clear();
    
    struct Stats {
        uint64_t hits;
        uint64_t misses;
        double hit_rate() const { return (double)hits / (hits + misses); }
    };
    
    Stats stats() const;
    
private:
    // Implement using:
    // - std::unordered_map for O(1) lookup
    // - std::list for LRU ordering
    // - std::shared_mutex for reader-writer lock
};
```

### Implementation Checklist

- [ ] Basic get/put operations
- [ ] LRU eviction when capacity reached
- [ ] TTL expiration check on get
- [ ] Background thread for periodic cleanup
- [ ] Memory tracking
- [ ] Statistics tracking
- [ ] Thread safety (read-write locks)
- [ ] Unit tests for:
  - [ ] Basic operations
  - [ ] LRU eviction
  - [ ] TTL expiration
  - [ ] Thread safety (concurrent get/put)
  - [ ] Memory limits
- [ ] Benchmarks (throughput, latency)
- [ ] Documentation

### Success Criteria

- **Correctness:** All tests pass
- **Performance:** 1M+ ops/sec for get operations
- **Concurrency:** No data races (test with ThreadSanitizer)
- **Coverage:** 80%+ code coverage

---

## Resources

### Books
- "Effective Modern C++" by Scott Meyers (Chapters 1-8)
- "C++ Concurrency in Action" (Chapter 1)

### Videos
- CppCon: Back to Basics (Smart Pointers, Move Semantics)
- CppCon: Move Semantics by Klaus Iglberger

### Practice
- LeetCode: Focus on problems requiring memory management
- Implement STL containers from scratch (great learning)

---

## Week 1 Deliverables

1. ✅ Completed all exercises (1-4)
2. ✅ Week 1 project (Object Cache) completed
3. ✅ All tests passing
4. ✅ README.md with benchmarks
5. ✅ Code pushed to GitHub

**Next Week:** Concurrency & Multithreading - Build a thread pool and thread-safe queue!
